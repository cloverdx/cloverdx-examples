Data comes from US Census Bureau:
* last_names.csv: was created from app_c.csv from 2000 census by removing all columns after prop100k
	http://www.census.gov/topics/population/genealogy/data/2000_surnames.html

* first_names_female.dat and first_names_male.dat: from 1990 census
	http://www.census.gov/topics/population/genealogy/data/1990_census.html